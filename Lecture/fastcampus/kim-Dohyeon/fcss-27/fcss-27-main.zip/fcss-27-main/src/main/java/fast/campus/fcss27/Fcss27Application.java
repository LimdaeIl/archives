package fast.campus.fcss27;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Fcss27Application {

    public static void main(String[] args) {
        SpringApplication.run(Fcss27Application.class, args);
    }

}
