package fast.campus.fcss27;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Fcss27ApplicationTests {

    @Test
    void contextLoads() {
    }

}
